public class VeiculoUtilitarios extends VeiculoPasseio {
    public VeiculoUtilitarios(String placa, String modelo, int anoFabricacao, double peso) {
        super(placa, modelo, anoFabricacao, peso);
        System.out.println("Veiculo Utilitário adicionado com sucesso!\n");
    }  
}
