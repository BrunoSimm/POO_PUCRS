public class VeiculoPasseio extends Veiculo {

    public VeiculoPasseio(String placa, String modelo, int anoFabricacao, double peso) {
        super(placa, modelo, anoFabricacao, peso);
        System.out.println("Veiculo Passeio adicionado com sucesso!\n");

    }
}
